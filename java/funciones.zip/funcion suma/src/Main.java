public class Main {
    public static void main(String[] args) {

        int resultado;
        resultado= suma(20,40,60);
        System.out.println("suma " +resultado);
   }
    public static int suma(int a,int b,int c){
       return a+b+c;
    }
}